
package hw08;

import java.io.IOException;
@SuppressWarnings("unchecked")
public class Hw08 {

   
   /* public static void main(String[] args) throws IOException {
        
        String filname="t1.txt";
        
        BigramMap<Integer> myBg;
        myBg = new BigramMap<>(1);
        
        myBg.readFile(filname);
    
        System.out.print("asd    "+myBg.numGrams());
        System.out.println(myBg.numOfGrams(1,4)+"      asdasdasd");
        
        System.out.print(myBg.toString());
    }*/
    
}

